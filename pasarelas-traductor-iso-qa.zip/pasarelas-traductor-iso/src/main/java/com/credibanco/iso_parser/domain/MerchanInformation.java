package com.credibanco.iso_parser.domain;

public class MerchanInformation {

	private String categoryCode = null;
	private String merchanName = null;
	private String countryCode = null;
	private String merchanCity = null;
	private String merchanAddress = null;
	private String merchantType = null;
	
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	public String getMerchanName() {
		return merchanName;
	}
	public void setMerchanName(String merchanName) {
		this.merchanName = merchanName;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getMerchanCity() {
		return merchanCity;
	}
	public void setMerchanCity(String merchanCity) {
		this.merchanCity = merchanCity;
	}
	public String getMerchanAddress() {
		return merchanAddress;
	}
	public void setMerchanAddress(String merchanAddress) {
		this.merchanAddress = merchanAddress;
	}
	public String getMerchantType() {
		return merchantType.trim();
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	
}
