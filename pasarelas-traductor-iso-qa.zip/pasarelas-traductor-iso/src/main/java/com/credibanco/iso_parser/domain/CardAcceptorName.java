package com.credibanco.iso_parser.domain;

public class CardAcceptorName extends LogicGeneradorMap {

	private String terminalOwnerName;
	private String terminalCity;
	private String terminalState;
	private String terminalCountry;
	
	public String getTerminalOwnerName() {
		return terminalOwnerName;
	}
	public void setTerminalOwnerName(String terminalOwnerName) {
		this.terminalOwnerName = terminalOwnerName;
	}
	public String getTerminalCity() {
		return terminalCity;
	}
	public void setTerminalCity(String terminalCity) {
		this.terminalCity = terminalCity;
	}
	public String getTerminalState() {
		return terminalState;
	}
	public void setTerminalState(String terminalState) {
		this.terminalState = terminalState;
	}
	public String getTerminalCountry() {
		return terminalCountry;
	}
	public void setTerminalCountry(String terminalCountry) {
		this.terminalCountry = terminalCountry;
	}
	
}
