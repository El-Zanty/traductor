package com.credibanco.iso_parser.infrastructure.configuration;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.credibanco.iso_parser.domain.DataField;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "com.credibanco.objects")
public class FieldsProperties {
	
	private List<String> transaction;
	
	private Map<String, List<String>> subFields;
	
	private Map<String, DataField> isoMap;

}
