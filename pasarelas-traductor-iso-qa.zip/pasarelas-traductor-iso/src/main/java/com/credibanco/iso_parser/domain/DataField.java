package com.credibanco.iso_parser.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataField {

	private int type;
	private String format;
	private Object values;
	private String fieldName;
	private int fieldNumber;
	
}
