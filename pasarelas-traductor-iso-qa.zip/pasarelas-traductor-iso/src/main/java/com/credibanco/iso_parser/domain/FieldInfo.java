package com.credibanco.iso_parser.domain;

import java.util.List;

public class FieldInfo {
	
	private List<String> fields;
	
	public List<String> getFields() {
		return fields;
	}
	public void setFields(List<String> fields) {
		this.fields = fields;
	}

}
