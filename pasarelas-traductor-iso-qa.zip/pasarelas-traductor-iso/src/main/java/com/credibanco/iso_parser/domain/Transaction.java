package com.credibanco.iso_parser.domain;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import com.credibanco.iso_parser.application.utils.LocalDateDeserializer;
import com.credibanco.iso_parser.application.utils.LocalDateSerializer;
import com.credibanco.iso_parser.application.utils.MaskUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Transaction extends LogicGeneradorMap {

	private MessageType messageType;
	private ProcessingCode processingCode;
	private String transactionAmount;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy HH:mm:ss", timezone = "America/Bogota")
	private Date transmissionDateTime;
	private String systemsTraceAuditNumber;
	private LocalTime localTransactionTime;
	@JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate localTransactionDate;
	@JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate captureDate;
	private String merchantType;
	private PointOfServiceEntryMode entryMode;
	private String posConditionCode;
	private String acquiringInstitutioncode;
	private Track2 track2;
	private String retrievalReferenceNumber;
	private String terminalIdentification;
	private CardAcceptorIdentificationCode cardAcceptorIdentificationCode;
	private CardAcceptorName cardAcceptorName;
	private AdditionalData additionalData;
	private RetailerData retailerData;
	private String transactionCurrencyCode;
	private String propina;
	private POSTerminalData posTerminalData;
	private POSCardIssuer posCardIssuer;
	private String additionalDataTokens;
	private String ReceivingInstitutionIdentificationCode;
	private String posBachShiftData;
	private String posSettlementData;
	private String authorizationIdentification;
	private OriginalDataElements originalDataElements;
	private String expirationDate;
	private String responseCode;
	private String reservedPrivate121;
	private String reservedPrivate123;
	private String reservedPrivate126;
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Transaction [");
		if (messageType != null) {
			builder.append("messageType=");
			builder.append(messageType);
			builder.append(", ");
		}
		if (processingCode != null) {
			builder.append("processingCode=");
			builder.append(processingCode);
			builder.append(", ");
		}
		if (transactionAmount != null) {
			builder.append("transactionAmount=");
			builder.append(transactionAmount);
			builder.append(", ");
		}
		if (transmissionDateTime != null) {
			builder.append("transmissionDateTime=");
			builder.append(transmissionDateTime);
			builder.append(", ");
		}
		if (systemsTraceAuditNumber != null) {
			builder.append("systemsTraceAuditNumber=");
			builder.append(systemsTraceAuditNumber);
			builder.append(", ");
		}
		if (localTransactionTime != null) {
			builder.append("localTransactionTime=");
			builder.append(localTransactionTime);
			builder.append(", ");
		}
		if (localTransactionDate != null) {
			builder.append("localTransactionDate=");
			builder.append(localTransactionDate);
			builder.append(", ");
		}
		if (captureDate != null) {
			builder.append("captureDate=");
			builder.append(captureDate);
			builder.append(", ");
		}
		if (merchantType != null) {
			builder.append("merchantType=");
			builder.append(merchantType);
			builder.append(", ");
		}
		if (entryMode != null) {
			builder.append("entryMode=");
			builder.append(entryMode);
			builder.append(", ");
		}
		if (posConditionCode != null) {
			builder.append("posConditionCode=");
			builder.append(posConditionCode);
			builder.append(", ");
		}
		if (acquiringInstitutioncode != null) {
			builder.append("acquiringInstitutioncode=");
			builder.append(acquiringInstitutioncode);
			builder.append(", ");
		}
		if (track2 != null) {
			builder.append("track2=");
			builder.append(track2);
			builder.append(", ");
		}
		if (retrievalReferenceNumber != null) {
			builder.append("retrievalReferenceNumber=");
			builder.append(retrievalReferenceNumber);
			builder.append(", ");
		}
		if (terminalIdentification != null) {
			builder.append("terminalIdentification=");
			builder.append(terminalIdentification);
			builder.append(", ");
		}
		if (cardAcceptorIdentificationCode != null) {
			builder.append("cardAcceptorIdentificationCode=");
			builder.append(cardAcceptorIdentificationCode);
			builder.append(", ");
		}
		if (cardAcceptorName != null) {
			builder.append("cardAcceptorName=");
			builder.append(cardAcceptorName);
			builder.append(", ");
		}
		if (additionalData != null) {
			builder.append("additionalData=");
			builder.append(additionalData);
			builder.append(", ");
		}
		if (retailerData != null) {
			builder.append("retailerData=");
			builder.append(retailerData);
			builder.append(", ");
		}
		if (transactionCurrencyCode != null) {
			builder.append("transactionCurrencyCode=");
			builder.append(transactionCurrencyCode);
			builder.append(", ");
		}
		if (propina != null) {
			builder.append("propina=");
			builder.append(propina);
			builder.append(", ");
		}
		if (posTerminalData != null) {
			builder.append("posTerminalData=");
			builder.append(posTerminalData);
			builder.append(", ");
		}
		if (posCardIssuer != null) {
			builder.append("posCardIssuer=");
			builder.append(posCardIssuer);
			builder.append(", ");
		}
		if (additionalDataTokens != null) {
			builder.append("additionalDataTokens=");
			builder.append(MaskUtil.maskCvv(additionalDataTokens));
			builder.append(", ");
		}
		if (ReceivingInstitutionIdentificationCode != null) {
			builder.append("ReceivingInstitutionIdentificationCode=");
			builder.append(ReceivingInstitutionIdentificationCode);
			builder.append(", ");
		}
		if (posBachShiftData != null) {
			builder.append("posBachShiftData=");
			builder.append(posBachShiftData);
			builder.append(", ");
		}
		if (posSettlementData != null) {
			builder.append("posSettlementData=");
			builder.append(posSettlementData);
			builder.append(", ");
		}
		if (authorizationIdentification != null) {
			builder.append("authorizationIdentification=");
			builder.append(authorizationIdentification);
			builder.append(", ");
		}
		if (originalDataElements != null) {
			builder.append("originalDataElements=");
			builder.append(originalDataElements);
			builder.append(", ");
		}
		if (expirationDate != null) {
			builder.append("expirationDate=");
			builder.append(expirationDate);
			builder.append(", ");
		}
		if (responseCode != null) {
			builder.append("responseCode=");
			builder.append(responseCode);
			builder.append(", ");
		}
		if (reservedPrivate121 != null) {
			builder.append("reservedPrivate121=");
			builder.append(reservedPrivate121);
			builder.append(", ");
		}
		if (reservedPrivate123 != null) {
			builder.append("reservedPrivate123=");
			builder.append(reservedPrivate123);
			builder.append(", ");
		}
		if (reservedPrivate126 != null) {
			builder.append("reservedPrivate126=");
			builder.append(reservedPrivate126);
		}
		builder.append("]");
		return builder.toString();
	}
	
	
	
}
