package com.credibanco.iso_parser.domain;

public class POSCardIssuer extends LogicGeneradorMap{
	private String cardIssuerFIID;
	private String cardlogicalNetword;
	private String category;
	private String saveAccountIndicator;
	private String interchangeResponseCode;
	
	public String getCardIssuerFIID() {
		return cardIssuerFIID;
	}
	public void setCardIssuerFIID(String cardIssuerFIID) {
		this.cardIssuerFIID = cardIssuerFIID;
	}
	public String getCardlogicalNetword() {
		return cardlogicalNetword;
	}
	public void setCardlogicalNetword(String cardlogicalNetword) {
		this.cardlogicalNetword = cardlogicalNetword;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSaveAccountIndicator() {
		return saveAccountIndicator;
	}
	public void setSaveAccountIndicator(String saveAccountIndicator) {
		this.saveAccountIndicator = saveAccountIndicator;
	}
	public String getInterchangeResponseCode() {
		return interchangeResponseCode;
	}
	public void setInterchangeResponseCode(String interchangeResponseCode) {
		this.interchangeResponseCode = interchangeResponseCode;
	}
}
