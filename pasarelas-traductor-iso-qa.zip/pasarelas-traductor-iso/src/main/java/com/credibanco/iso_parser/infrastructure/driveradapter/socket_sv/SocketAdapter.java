package com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv;

import static com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv.dtos.IsoDTOFactory.*;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.credibanco.iso_parser.domain.ports.out.TransactionAuthorizationRepository;
import com.credibanco.iso_parser.application.utils.HttpIso;
import com.credibanco.iso_parser.domain.FieldIso;
import com.credibanco.iso_parser.domain.UnPackIso;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SocketAdapter implements TransactionAuthorizationRepository{
	
	
	private Map<String, CompletableFuture<String>> pendingRequests = new ConcurrentHashMap<>();

	@Value("${SmartVista.timeout}")
	private Long timeoutSv;
	@Autowired
	@Lazy
	private SocketSmartVista socket;
	
	public List<FieldIso> sendToAuthorize(List<FieldIso> fields) throws TimeoutException, ExecutionException, InterruptedException {
		List<FieldIso> listResponse = null;
		String key = null; 
			try {
				List<FieldIso> listPack = HttpIso.pack(fields);
				key = this.getKeyFromFields(listPack);
				String trace = this.getTrace(listPack);
				log.info("Send to SV ---> {}", key);
				this.sendTrace(trace);
				CompletableFuture<String> future = new CompletableFuture<>();
				pendingRequests.put(key, future);
				String responseTrace;
				responseTrace = future.get(timeoutSv, TimeUnit.MILLISECONDS);
				log.info("SV Response <--- {}", key);
				listResponse = HttpIso.unPack(new UnPackIso(responseTrace));
				listResponse.add(new FieldIso(0, "Request Trace", trace));
				listResponse.add(new FieldIso(0, "Response Trace", responseTrace));
				listResponse.add(new FieldIso(0, "Request key", key));
			} catch (TimeoutException e) {
				log.error("Timeout error for key: {}", key);
				this.sendTrace(LOGON.getTrace().get());
				throw e;
			}catch(InterruptedException | ExecutionException  e){
				log.error("InterruptedException error or ExecutionException error.");
				throw e;
			}finally {
				pendingRequests.remove(key);
			}
			return listResponse;
	}
	
	public void matchResponse(String trace) {
		String key = this.getKeyForTrace(trace);
		if(key!=null) {
			CompletableFuture<String> future = pendingRequests.get(key);
			if(future!=null) {
				future.complete(trace);
				pendingRequests.remove(key);
			}	
		}
	}
	
	private String getKeyForTrace(String trace) {
		List<FieldIso> fields = HttpIso.unPack(new UnPackIso(trace));
		StringBuilder key = new StringBuilder();
        String responseCode = "";
        boolean solicitudSV = false;
        boolean adminMessage = false;
        String adminTipoSolicitud = "";
        boolean reverso = false;
		for (FieldIso fieldIso : fields) {
        	if (fieldIso.getId() == 0 && fieldIso.getName().equalsIgnoreCase("Message Type Indicator")) {
        		if(fieldIso.getValue().equalsIgnoreCase("0810") || fieldIso.getValue().equalsIgnoreCase("0800") ) {
        			if ( fieldIso.getValue().equalsIgnoreCase("0800") ) {
        				solicitudSV = true;            				
					} 
        			adminMessage = true;
        		}else if(fieldIso.getValue().equalsIgnoreCase("0210")) {
        			key.append("0200");
        		}else if(fieldIso.getValue().equalsIgnoreCase("0430")||fieldIso.getValue().equalsIgnoreCase("0420")) {
        			reverso = true;
        			key.append("0420");
        		}
			}else if( fieldIso.getId() == 7 && fieldIso.getName().equalsIgnoreCase("Transmission date & time") &&  reverso) {
				key.append(fieldIso.getValue());
        	}else if( fieldIso.getId() == 11 && fieldIso.getName().equalsIgnoreCase("Systems trace audit number") && reverso) {
        		key.append(fieldIso.getValue());
			}else if( fieldIso.getId() == 13 && fieldIso.getName().equalsIgnoreCase("Date, Local transaction (MMdd)") && !reverso) {
				key.append(fieldIso.getValue());
			}else if( fieldIso.getId() == 37 && fieldIso.getName().equalsIgnoreCase("Retrieval reference number")  && !reverso) {
				key.append(fieldIso.getValue());
			}else if( fieldIso.getId() == 39 ) {
        		responseCode = fieldIso.getValue();
			}else if( fieldIso.getId() == 70 ) {
        		adminTipoSolicitud = fieldIso.getValue();
			}
		}
		if (adminMessage) {
        	if ( !solicitudSV && responseCode.equalsIgnoreCase("00") && adminTipoSolicitud.equals("001")) {
        		this.sendTrace(ECO.getTrace().get());
			}else if (solicitudSV  && adminTipoSolicitud.equals("001")) {
				this.sendTrace(LOGON_RESPONSE.getTrace().get());
			}else if(solicitudSV  && adminTipoSolicitud.equals("301")) {
				this.sendTrace(ECO_RESPONSE.getTrace().get());
			}else if( solicitudSV  && adminTipoSolicitud.equals("002")) {
				this.sendTrace(LOGOFF_RESPONSE.getTrace().get());
			}
        	return null;
		} else {
			return key.toString();
		}
	}

	private String getTrace(List<FieldIso> listPack) {
		String trace = "";
		for (FieldIso fieldIso : listPack) {
			if ( fieldIso.getId() == 0 && fieldIso.getName().equalsIgnoreCase("payLoad") ) {
				if(fieldIso.getValue().contains("! D300260")){
					trace = modTokenD3(fieldIso);
				}else {
					trace = fieldIso.getValue().toUpperCase();
				}
				break;
			}
		}
		return trace;
	}

	private String getKeyFromFields(List<FieldIso> listPack) {
		StringBuilder key = new StringBuilder();
		boolean reverso = false;
		String mtype= "";
		for (FieldIso fieldIso : listPack) {
			if( fieldIso.getId() == 0 && fieldIso.getName().equalsIgnoreCase("Message Type Indicator") ) {
				mtype = fieldIso.getPackedValue();
				key.append(mtype.trim().equals("0421") ? "0420" : mtype);
				if(mtype.trim().equals("0420") || mtype.trim().equals("0421")) {
					reverso = true; 
				}
			}else if( fieldIso.getId() == 7 && fieldIso.getName().equalsIgnoreCase("Transmission date & time") && reverso) {
        		key.append(fieldIso.getValue());
			}else if( fieldIso.getId() == 11 && fieldIso.getName().equalsIgnoreCase("Systems trace audit number") && reverso) {
				key.append(fieldIso.getValue());
			}else if( fieldIso.getId() == 13 && fieldIso.getName().equalsIgnoreCase("Date, Local transaction (MMdd)") && !reverso ) {
        		key.append(fieldIso.getValue());
        	}else if( fieldIso.getId() == 37 && fieldIso.getName().equalsIgnoreCase("Retrieval reference number") && !reverso) {
        		key.append(fieldIso.getValue());
			}
		}
		return key.toString();
	}
	
	private String modTokenD3( FieldIso fieldIso){
		String trace = fieldIso.getValue();
		int initIndexToken = trace.indexOf("! D300260");
		int endIndexToken = initIndexToken + 270;
		String token = trace.substring(initIndexToken, endIndexToken);
		StringBuilder tokenMod = new StringBuilder();
		tokenMod.append(token.substring(0,51).toUpperCase());
		tokenMod.append(token.substring(51));
		StringBuilder sb = new StringBuilder();
		sb.append(trace.substring(0, initIndexToken).toUpperCase());
		sb.append(tokenMod);
		sb.append(trace.substring(endIndexToken).toUpperCase());
		return sb.toString();

	}
	
	private void sendTrace(String trace) {
		boolean send = true;
		do {
			if(send && !socket.isReconnect()) {
				socket.send(trace);
				send = false;
			}
		} while (send);
	}

}
