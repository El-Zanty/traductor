package com.credibanco.iso_parser.domain;

import com.credibanco.iso_parser.infrastructure.entrypoint.controller.out.AutorizarResponseDto;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum ResponseFactory {

    TO_TRANSACTION(AutorizarResponseDto.builder()
            .responseCode("TO")
            .menssage("No se encontro la transaccion")
            .build()),
    TO_TIMEOUT(AutorizarResponseDto.builder()
            .responseCode("TO")
            .menssage("Timeout")
            .build()),
    INTERNAL_ERRORS(AutorizarResponseDto.builder()
            .responseCode("99")
            .menssage("Error interno de la aplicacion")
            .build()),
    ISO_CONVERTION_ERROR(AutorizarResponseDto.builder()
            .responseCode("58")
            .menssage("Error en convertir el objeto a ISO")
            .build());

    private final AutorizarResponseDto autorizarResponseDto;
}
