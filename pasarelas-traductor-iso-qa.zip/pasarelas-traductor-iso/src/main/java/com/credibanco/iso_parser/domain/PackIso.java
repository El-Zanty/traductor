package com.credibanco.iso_parser.domain;

import java.util.List;

public class PackIso {

	private String options = "fh";
	private List<FieldIso> fields;
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	public List<FieldIso> getFields() {
		return fields;
	}
	public void setFields(List<FieldIso> fields) {
		this.fields = fields;
	}
	
}
