package com.credibanco.iso_parser.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UnPackIso {

	private String trace;
	private String options = "lhf";
	
	public UnPackIso(String trace) {
		super();
		this.trace = trace;
	}
	
}
