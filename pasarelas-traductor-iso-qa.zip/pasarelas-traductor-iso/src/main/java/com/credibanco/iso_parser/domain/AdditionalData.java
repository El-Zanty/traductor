package com.credibanco.iso_parser.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdditionalData extends LogicGeneradorMap {

	private String IVA;
	private String baseDevolucion;
	private String IAC;
	
}
