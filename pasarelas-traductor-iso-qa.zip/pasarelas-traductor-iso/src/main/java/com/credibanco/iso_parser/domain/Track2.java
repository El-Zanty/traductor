package com.credibanco.iso_parser.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Track2 extends LogicGeneradorMap {

	private String pan;
	@JsonIgnore
	private String separador = "=";
	private String expirationDate;
	private String serviceCode;
	private String discretionaryData;
	private String endSentinel;
	private String longitudinalRedundancyCheck;
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Track2 [");
		if (pan != null) {
			builder.append("pan=");
			builder.append(pan.substring(0, 6));
			builder.append("******");
			builder.append(pan.substring(pan.length() - 4));
			builder.append(", ");
		}
		if (separador != null) {
			builder.append("separador=");
			builder.append(separador);
			builder.append(", ");
		}
		if (expirationDate != null) {
			builder.append("expirationDate=");
			builder.append(expirationDate);
			builder.append(", ");
		}
		if (serviceCode != null) {
			builder.append("serviceCode=");
			builder.append(serviceCode);
			builder.append(", ");
		}
		if (discretionaryData != null) {
			builder.append("discretionaryData=");
			builder.append(discretionaryData);
			builder.append(", ");
		}
		if (endSentinel != null) {
			builder.append("endSentinel=");
			builder.append(endSentinel);
			builder.append(", ");
		}
		if (longitudinalRedundancyCheck != null) {
			builder.append("longitudinalRedundancyCheck=");
			builder.append(longitudinalRedundancyCheck);
		}
		builder.append("]");
		return builder.toString();
	}
	
	
	
}
