package com.credibanco.iso_parser.domain;

public class OriginalDataElements extends LogicGeneradorMap{
	private String originalTransactionType;
	private String originalSecuenceNumber;
	private String transactionDate;
	private String transactionTime;
	private String originalCaptureDate;
	private String filler;
	
	public String getOriginalTransactionType() {
		return originalTransactionType;
	}

	public void setOriginalTransactionType(String originalTransactionType) {
		this.originalTransactionType = originalTransactionType;
	}

	public String getOriginalSecuenceNumber() {
		return originalSecuenceNumber;
	}

	public void setOriginalSecuenceNumber(String originalSecuenceNumber) {
		this.originalSecuenceNumber = originalSecuenceNumber;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getOriginalCaptureDate() {
		return originalCaptureDate;
	}

	public void setOriginalCaptureDate(String originalCaptureDate) {
		this.originalCaptureDate = originalCaptureDate;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
	
}
