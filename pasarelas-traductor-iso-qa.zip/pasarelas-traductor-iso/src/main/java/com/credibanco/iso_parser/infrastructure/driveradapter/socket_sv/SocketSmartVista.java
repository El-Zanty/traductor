package com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv;

import static com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv.dtos.IsoDTOFactory.ECO;
import static com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv.dtos.IsoDTOFactory.LOGON;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;

import com.credibanco.iso_parser.application.utils.MaskUtil;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class SocketSmartVista {
	
	@Getter
	private final String ip;
	@Getter
	private final int port;
	private final Long reconnectDelay;
	private final Long echoFrecuency;
	private final SocketAdapter socketAdapter;
	private final ExecutorService executor;
	private final int maxRetryConnection;
	private final boolean reset;
	
	private final Object lock = new Object();
	
	@Getter
	private boolean reconnect = false;
	private Socket socket;
	private DataInputStream bufferIn;
	private DataOutputStream bufferOut;
	private InputStream inputStream;
	private OutputStream outputStream;
	private ExecutorService executorEcos = Executors.newSingleThreadExecutor();
	private ExecutorService executorRead = Executors.newSingleThreadExecutor();
	private int resetCounter = 0;
	
	@PostConstruct
	public void postConstruct() {
		try {
			socket = new Socket(ip, port);
			inputStream = socket.getInputStream();
			outputStream = socket.getOutputStream();
			bufferIn = new DataInputStream(inputStream);
			bufferOut = new DataOutputStream(outputStream);
			bufferOut.flush();
			executorRead.execute(() -> {
					try {
						send(LOGON.getTrace().get());
						while (socket != null && socket.isConnected() && !reconnect) {
							read();
						}
					} catch (Exception e1) {
						log.error("run(): ", e1);
					}
			});
			executorEcos.execute(() -> {
					try {
						echoManagment();
					} catch (Exception e) {
						log.error("run(): ", e);
					}
	        });
		}catch(Exception e) {
			log.error(String.format("No se pudo inicializar la conexion por el puerto %d", this.port));
		}
	}
	
	public void send(String s) {
		try {
			synchronized (lock) {
				bufferOut.writeUTF(s);
				bufferOut.flush();
			}
			if(log.isTraceEnabled()) {
				log.trace("SmartVista {}:{} ---> {}",ip ,port , MaskUtil.maskTrace(s));
			}
		} catch (IOException e) {
			log.error("send(): ", e);
			reconnect();
		}
	}
	
	public void read() {
		String inputString;
    	try {
    			inputString = bufferIn.readUTF();
	    		if(log.isTraceEnabled()) {
					log.trace("SmartVista {}:{} <--- {}",ip ,port, MaskUtil.maskTrace(inputString));
				}
	    		executor.execute(() -> socketAdapter.matchResponse(inputString));
				this.resetCounter = 0;
        }catch (EOFException e) {
        	log.error("Error leyendo el socket ", e);
        	reconnect();
		} catch (IOException e) {
        	log.error("Error leyendo el socket ", e);
        	reconnect();
		}
	}
	
	private void reconnect() {
	    try {
			this.resetCounter += 1;
			if(resetCounter > maxRetryConnection && reset){
				this.killPod();
			}
	    	this.reconnect = true;
	    	log.info("Connection recovery start");
	        closeConnection();
	        Thread.sleep(reconnectDelay);
			postConstruct();
			this.reconnect = false;
	    } catch (InterruptedException e) {
	        log.error("Error en el proceso de reconexión: " + e.getMessage());
	        Thread.currentThread().interrupt();
	    }finally {
	    	this.reconnect = false;
		}
	}
	
	private void closeConnection() {
	    try {
	        if (bufferIn != null) {
	            bufferIn.close();
	        }
	        if (bufferOut != null) {
	            bufferOut.close();
	        }
	        if (socket != null) {
	            socket.close();
	        }
	    } catch (IOException e) {
	        log.error("Error al cerrar la conexión: " + e.getMessage());
	    }
	}
	
	public boolean isAvailable() throws IOException {
		try {
			socket = new Socket(ip, port);
			bufferIn = new DataInputStream(socket.getInputStream());
			bufferOut = new DataOutputStream(socket.getOutputStream());
			bufferOut.writeUTF(LOGON.getTrace().get());
			bufferOut.flush();
			bufferIn.readUTF();
			return true;
		}catch( IOException | SecurityException | IllegalArgumentException e) {
			log.error("Error en la conexión con el socket, socket no disponible");
		}finally {
			if (bufferIn != null) {
	            bufferIn.close();
	        }
	        if (bufferOut != null) {
	            bufferOut.close();
	        }
	        if (socket != null) {
	            socket.close();
	        }
		}
		return false;
	}
	
	public void echoManagment() {
		while (!Thread.currentThread().isInterrupted() && this.socket.isConnected()) {
			try {
				Thread.sleep(echoFrecuency);
				this.send( ECO.getTrace().get() );
			} catch (InterruptedException e) {
				log.error("manejarEcos(): ", e);
				Thread.currentThread().interrupt();
				break;
			}
		}
	}


	private void killPod(){
		System.exit(0);
	}

}
