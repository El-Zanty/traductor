package com.credibanco.iso_parser.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MessageType extends LogicGeneradorMap{
	
	private String claseMensaje;
	private String funcionMensaje;
	
}
